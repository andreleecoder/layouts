import React from 'react';

const App = () => {
  return <div>Meu App Teste</div>;
};

export default App;
