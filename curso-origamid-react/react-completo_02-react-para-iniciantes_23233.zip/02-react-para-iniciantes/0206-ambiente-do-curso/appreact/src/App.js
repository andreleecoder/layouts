import React from 'react';

const App = () => {
  return <div>Meu app</div>;
};

export default App;
