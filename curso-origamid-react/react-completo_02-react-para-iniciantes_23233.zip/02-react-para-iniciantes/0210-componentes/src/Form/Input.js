import React from 'react';

const Input = () => {
  return <input type="text" />;
};

export default Input;
